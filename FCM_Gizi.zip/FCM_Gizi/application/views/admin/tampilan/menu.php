 <!-- Main Header -->
<header class="main-header">

      <!-- Logo -->
      <a href="<?php echo base_url('admin/index')?>" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>S</b></span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>GIZI BALITA</b></span>
      </a>

  <!-- Header Navbar -->
  <nav class="navbar navbar-static-top" role="navigation">
    <!-- Sidebar toggle button-->
    <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
      <span class="sr-only"></span>
    </a>
  </nav>
</header>

<aside class="main-sidebar">
  <section class="sidebar">
    <section class="sidebar">
    <!-- Sidebar Menu -->
    <ul class="sidebar-menu">
      <!-- beranda -->
      <li><a href="<?php echo base_url('admin/index')?>"><i class="ace-icon fa fa-home home-icon"></i><span> Beranda</span>
          </span>
        </a>
      </li>
      <!-- data latih -->
      <li><a href="<?php echo base_url('Admin_data_latih/input_data_latih')?>"><i class="menu-icon fa fa-book"></i><span> Data Latih</span>
          </span>
        </a>
      </li>
      <!-- data uji dan akurasi -->
      <li><a href="<?php echo base_url('Admin_data_uji/input_data_uji')?>"><i class="menu-icon fa fa-pencil-square-o"></i><span> Data Uji dan Akurasi</span>
          </span>
        </a>
      </li>
      <!-- cek status gizi -->
      <li><a href="<?php echo base_url('Admin_data_balita/input_data_balita')?>"><i class="menu-icon fa fa-check-square-o"></i><span> Cek Status Gizi</span>
          </span>
        </a>
      </li>
    </ul>
  </section>
</aside>
