<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <?php $this->load->view('templates/js') ?>
  <title>GIZI BALITA</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/font-awesome.min.css')?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/dataTables.bootstrap.min.css')?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/AdminLTE.min.css')?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/skins/skin-blue.min.css')?>">
  <link href="<?php echo base_url('assets/img/admin.jpg')?>" rel="shortcut icon" type="image/x-icon">
</head>



<body class="hold-transition skin-blue sidebar-mini">

  <div class="wrapper">
    <?php include 'menu.php'; ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <section class="content-header">
        <h1>Implementasi Metode FCM untuk Klasifikasi Status Gizi pada Balita berdasarkan Indeks Antropometri <small>Dashboard</small></h1>
      </section>

      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <h4> Input Data Uji Baru</h4>
          </div>
          <div class="box-tools" style="padding:10px;">
          <?php if ($this->session->flashdata('sukses')) { ?>
            <div class="">

              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
              <?php echo $this->session->flashdata('sukses'); ?></div>
            </div>
          <?php } ?>
          <?php if ($this->session->flashdata('edit')) { ?>
            <div class="">
              <div class="alert alert-warning">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
              <?php echo $this->session->flashdata('edit'); ?></div>
            </div>
          <?php } ?>
          <?php if ($this->session->flashdata('gagal')) { ?>
            <div class="">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
              <?php echo $this->session->flashdata('gagal'); ?></div>
            </div>
          <?php } ?>
          </div>

          <!-- Insert -->
          <?php if (isset($_POST['tambah'])) { ?>
            <div class="row">
              <div class="box">
                <!-- header -->
                <div class="box-header with-border">
                  <h3 class="box-title">Tambah Data</h3>
                  <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div>
                </div>
                <!-- body -->
                <div class="box-body">
                  <form class="" action="<?php echo base_url('Admin_data_balita/simpan_data_balita')?>" method="post">
                    <div class="form-group row">
                      <div class="col-sm-2">
                        Nama Balita
                      </div>
                      <div class="col-sm-5">
                        <input type="text" name="nama" class="form-control" placeholder="Nama Balita" required="true">
                      </div>
                    </div>
                    <div class="form-group row">
                      <div class="col-sm-2">
                        Jenis Kelamin
                      </div>
                      <div class="col-sm-5">
                        <select class="form-control" name="jenis_kelamin" required="">
                        <option value="">Pilih</option>
                        <option value="Perempuan">Perempuan</option>
                        <option value="Laki-laki">Laki-laki</option>
                      </select>
                      </div>
                    </div>
                    <div class="form-group row">
                      <div class="col-sm-2">
                        Umur (0-60 bulan)
                      </div>
                      <div class="col-sm-5">
                        <input type="text" name="umur" class="form-control" placeholder="Umur" required="true">
                      </div>
                    </div>
                    <div class="form-group row">
                      <div class="col-sm-2">
                        Tinggi Badan (meter)
                      </div>
                      <div class="col-sm-5">
                        <input type="text" name="tinggi_badan" class="form-control" placeholder="Tinggi Badan" required="true">
                      </div>
                    </div>
                    <div class="form-group row">
                      <div class="col-sm-2">
                        Berat Badan (kg)
                      </div>
                      <div class="col-sm-5">
                        <input type="text" name="berat_badan" class="form-control" placeholder="Berat badan" required="true">
                      </div>
                    </div>
                    <div class="form-group row">
                      <div class="col-sm-2">
                        C1
                      </div>
                      <div class="col-sm-5">
                        <input type="text" name="C_1" class="form-control" placeholder="<?php echo"$c1" ?>" value="<?php echo"$c1" ?>"required="true" readonly="">
                      </div>
                    </div>
                    <div class="form-group row">
                      <div class="col-sm-2">
                        C2
                      </div>
                      <div class="col-sm-5">
                        <input type="text" name="C_2" class="form-control" placeholder="<?php echo"$c2" ?>" value="<?php echo"$c2" ?>"required="true" readonly="">
                      </div>
                    </div>
                    <div class="form-group row">
                      <div class="col-sm-2">
                        C3
                      </div>
                      <div class="col-sm-5">
                        <input type="text" name="C_3" class="form-control" placeholder="<?php echo"$c3" ?>" value="<?php echo"$c3" ?>"required="true" readonly="">
                      </div>
                    </div>
                    <div class="form-group row">
                      <div class="col-sm-2">
                        C4
                      </div>
                      <div class="col-sm-5">
                        <input type="text" name="C_4" class="form-control" placeholder="<?php echo"$c4" ?>" value="<?php echo"$c4" ?>" required="true" readonly="">
                      </div>
                    </div>
                    <div class="form-group row">
                      <div class="col-sm-2">
                        Status Gizi
                      </div>
                      <div class="col-sm-5">
                        <select class="form-control" name="status_gizi" required="">
                        <option value="">Pilih</option>
                        <option value="Sangat Kurus">Sangat Kurus</option>
                        <option value="Kurus">Kurus</option>
                        <option value="Normal">Normal</option>
                        <option value="Gemuk">Gemuk</option>
                      </select>
                      </div>
                    </div>
                      <div class="row">
                        <div class="form-group">
                          <div class="col-md-8 col-md-push-4">
                            <button type="submit" class="btn btn-primary" name="tambah_data" id="simpan">
                              <i class="fa fa-save"></i> Proses
                            </button>
                            <a href="input_data_balita" class="btn btn-danger">
                              <i class="fa fa-times"></i> Batal
                            </a>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              </div>
              <?php } ?>

              <div class="row">
                <div class="col-lg-2">

                  <div class="box-tools right">
                    <div class="input-group input-group-sm" style="width: 150px;">
                      <form action="" method="post">
                        <button type="submit" name="tambah" class="btn btn-primary">
                          <i class="fa fa-user-plus"></i> Tambahkan Data
                        </button>
                      </form>
                    </div>

                  </div>
                </div>
                <div class="col-lg-10">

                  <!-- <form action="#" method="post">
                  <a name="normalisasi" class="btn btn-success">
                    <i class="fa fa-eye" href="<?php echo base_url('Admin_data_balita/normalisasi')?>" method="post"></i> Normalisasi
                  </a>
                  <div class="box-body">
                    <form class="" action="<?php echo base_url('Admin_data_balita/normalisasi')?>" method="post">
                      </form>
                    </div>
                  </div>
                    <button type="submit" name="print" class="btn btn-primary pull-right">
                      <i class="fa fa-print"></i> Print Data
                    </button>
                  </form> -->
                </div>
              </div>

              <!-- View -->
              <div class="row">
                <div class="col-lg-1-12">
                  <div class="box">
                    <div class="box-body">
                      <table  id="example1" class="table table-hover table-bordered table-responsive">
                        <thead>
                          <tr class="bg-blue">
                            <th>No.</th>
                            <th>Nama Balita</th>
                            <th>Jenis Kelamin</th>
                            <th>Umur (Bulan)</th>
                            <th>Tinggi Badan (meter)</th>
                            <th>Berat Badan (kg)</th>
                            <th>C1</th>
                            <th>C2</th>
                            <th>C3</th>
                            <th>C4</th>
                            <th>Hasil Status Gizi</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $no = 1 ?>
                          <?php foreach ($data_balita as $input_data_balita): ?>
                            <tr>
                              <td><?php echo $no++ ?></td>
                              <td><?php echo $input_data_balita->nama ?></td>
                              <td><?php echo $input_data_balita->jenis_kelamin ?></td>
                              <td><?php echo $input_data_balita->umur ?></td>
                              <td><?php echo $input_data_balita->tinggi_badan ?></td>
                              <td><?php echo $input_data_balita->berat_badan ?></td>
                              <td><?php echo $input_data_balita->C_1 ?></td>
                              <td><?php echo $input_data_balita->C_2 ?></td>
                              <td><?php echo $input_data_balita->C_3 ?></td>
                              <td><?php echo $input_data_balita->C_4 ?></td>
                              <td><?php echo $input_data_balita->status_gizi ?></td>

                              <td>
                                <form class="" action="delete_data_balita" method="post">
                                  <div class="btn-group-horizontal btn-group-sm">
                                    <!-- buat mengedit di tambahi edit  -->
                                    <a type="submit" name="ubah" class="btn btn-warning" onClick="edit_data_balita('<?php echo $input_data_balita->id_data_balita; ?>')"><i class="fa fa-pencil"></i> Edit</a>

                                    <input type="hidden" name="id_data_balita" value="<?php echo $input_data_balita->id_data_balita; ?>">

                                    <button type="submit" name="delete_data_balita" class="btn btn-danger" onclick="return confirm('yakin mau dihapus ?')" >
                                      <i class="fa fa-eraser"></i> Hapus
                                    </button>
                                  </div>
                                </form>
                              </td>
                            </tr>

                          <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="box-tools"  align="center">
                    <div class="input-group input-group-sm" style="width: 50px;">
                    </div>
                  </div>
                </div>
              </div>
            </section>
            <!-- /.content -->


          </div>
          <!-- /.content-wrapper -->

          <!-- Main Footer -->
          <footer class="main-footer">
            <strong>&copy; Copyright <a href="#">Implementasi Metode Fuzzy C-Means untuk Klasifikasi Gizi Balita <?php echo date('Y') ?></a>.</strong>
          </footer>
        </div>
        <!-- REQUIRED JS SCRIPTS -->

        <!-- modal edit data pegawai -->
        <div class="modal fade" id="modal_edit_data_balita" role="dialog">
          <div class="modal-dialog">
            <div class="modal-content">
              <!-- Modal Header -->
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                  <span aria-hidden="true">&times;</span>
                  <span class="sr-only">Tutup</span>
                </button>
                <h4 class="modal-title" id="labelModalKu">Edit Data uji</h4>
              </div>

              <!-- Modal Body -->
              <div class="modal-body">
                <p class="statusMsg"></p>
                <form action="<?php echo base_url('Admin_data_balita/update_data_balita')?>" method="post">
                  <input type="hidden" class="form-control" id="id_data_balita" name="id_data_balita" readonly/>
                  <div class="form-group row">
                    <div class="col-sm-2">
                      Nama Balita
                    </div>
                    <div class="col-sm-5">
                      <input type="text" name="nama" class="form-control" placeholder="Nama Balita" required="true">
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-sm-2">
                      Jenis Kelamin
                    </div>
                    <div class="col-sm-5">
                      <select class="form-control" name="status_gizi" required="">
                      <option value="">Pilih</option>
                      <option value="Perempuan">Perempuan</option>
                      <option value="Laki-laki">Laki-laki</option>
                    </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-sm-2">
                      Umur (0-60 bulan)
                    </div>
                    <div class="col-sm-5">
                      <input type="text" name="umur" class="form-control" placeholder="Umur" required="true">
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-sm-2">
                      Tinggi Badan (meter)
                    </div>
                    <div class="col-sm-5">
                      <input type="text" name="tinggi_badan" class="form-control" placeholder="Tinggi Badan" required="true">
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-sm-2">
                      Berat Badan (kg)
                    </div>
                    <div class="col-sm-5">
                      <input type="text" name="berat_badan" class="form-control" placeholder="Berat badan" required="true">
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-sm-2">
                      Status Gizi
                    </div>
                    <div class="col-sm-5">
                      <select class="form-control" name="status_gizi" required="">
                      <option value="">Pilih</option>
                      <option value="Sangat Kurus">Sangat Kurus</option>
                      <option value="Kurus">Kurus</option>
                      <option value="Normal">Normal</option>
                      <option value="Gemuk">Gemuk</option>
                    </select>
                    </div>

                  <div class="form-group">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary submitBtn">KIRIM</button>
                  </div>
                </form>
              </div>
              <!-- Modal Footer -->
            </div>
          </div>
        </div>

        <!-- jQuery 2.2.3 -->
        <script src="<?php echo base_url('assets/js/jquery-2.2.3.min.js')?>"></script>

        <!-- buat manggil modal jQuery ui-->
        <script src="<?php echo base_url('assets/js/jquery-ui.js')?>"></script>

        <!-- jquery Data Tables -->
        <script src="<?php echo base_url('assets/js/jquery.dataTables.js')?>"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/jquery.dataTables.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/dataTables.bootstrap.css">

        <!-- Bootstrap 3.3.6 -->
        <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo base_url('assets/js/app.min.js')?>"></script>
      </body>

      <!-- ajax untuk menampilkan edit -->
      <script type="text/javascript">

      // //mengambil kode_petak dari tabel detail_target_getah
      // function get_kode_nps(){
      //   bulan=$('#bulan').val();
      //   periode=$('#periode').val();
      //   tahun=$('#tahun').val();
      //   $.ajax({
      //     url :"<?php echo base_url('Admin_angkutan/get_kodepetak/')?>",
      //     type : "post",
      //     data     : {'bulan':bulan,'periode':periode,'tahun':tahun},
      //     dataType :"json",
      //     success  :function(data){
      //       $('#kode_petak_tambah').html(data);
      //     }
      //   });
      // }
      //
      // function get_paste_kode_nps(){
      //   bulan=$('#bulan').val();
      //   periode=$('#periode').val();
      //   tahun=$('#tahun').val();
      //   $.ajax({
      //     url :"<?php echo base_url('Admin_angkutan/get_kodepetak_nps/')?>",
      //     type : "post",
      //     data     : {'bulan':bulan,'periode':periode,'tahun':tahun},
      //     dataType :"json",
      //     success  :function(data){
      //       // $('#kode_petak_tambah').html(data);
      //       console.log(data.kode_nps);
      //       // alert(data.id_detailtarget);
      //       // die();
      //       $('#paste_kode_nps').val(data.kode_nps);
      //     }
      //   });
      // }
      //
      // //mengambil id_detailtarget
      // function getDetailTarget(){
      //   kode_petak=$('#kode_petak_tambah').val();
      //   $.ajax({
      //     url :'<?php echo base_url('Admin_sadapan/get_id_detailtarget/')?>'+kode_petak,
      //     type : 'get',
      //     success : function(data){
      //       // document.write(nps.id_detailtarget);
      //       console.log(data.id_detailtarget);
      //       // alert(data.id_detailtarget);
      //       // die();
      //       $('#detail_target').val(data.id_detailtarget);
      //     }
      //   });
      //
      // }



      function edit_data_balita(id_data_balita) {
        $.ajax({
          type: 'get',
          url : '<?php echo base_url('Admin_data_balita/edit_data_balita?id_data_balita=')?>'+id_datid_data_balita, //pemanggilan controller edit

          success: function(hasil) {
            $response = $(hasil);
            // ambil data dari url admin/edit_barang?id_barang=(sekian)
            var id_data_balita = $response.filter('#id_data_balita').text();
            var nama = $response.filter('#nama').text();
            var jenis_kelamin = $response.filter('#jenis_kelamin').text();
            var umur = $response.filter('#umur').text();
            var tinggi_badan = $response.filter('#tinggi_badan').text();
            var berat_badan = $response.filter('#berat_badan').text();
            var status_gizi = $response.filter('#status_gizi').text();

            // nampilkan ke modal
            $('#id_data_balita').val(id_data_balita);
            $('#nama').val(nama);
            $('#jenis_kelamin').val(jenis_kelamin);
            $('#umur').val(umur);
            $('#tinggi_badan').val(tinggi_badan);
            $('#berat_badan').val(berat_badan);
            $('#status_gizi').val(status_gizi);
            $('#modal_edit_data_sadapan').modal('show');

          }
        });
      }

      </script>

      <script type="text/javascript">
      $(document).ready(function(){
        $('#example1').DataTable();
      });
      </script>

      </html>
