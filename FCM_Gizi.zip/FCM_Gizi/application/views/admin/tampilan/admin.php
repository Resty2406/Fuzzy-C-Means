<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <title>GIZI BALITA</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/font-awesome.min.css')?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/AdminLTE.min.css')?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/skins/skin-blue.min.css')?>">
  <link href="<?php echo base_url('assets/img/admin.jpg')?>" rel="shortcut icon" type="image/x-icon">
</head>

<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">
  <?php include 'menu.php'; ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Implementasi Metode FCM untuk Klasifikasi Status Gizi pada Balita berdasarkan Indeks Antropometri <small>Dashboard</small></h1>
    </section>

    <section class="content">
      <div class="row">
      <!-- BAR CHART -->
      <div class="box box-primary">
        <div class="box-body" align="center">
          <h1> Selamat Datang </h1>
          <h5>Implementasi Metode FCM untuk Klasifikasi Status Gizi pada Balita berdasarkan Indeks Antropometri</h5>
          <div class="chart">
            <canvas id="salesChart" style="height: 180px; width: 661px;" height="180" width="661">
            </canvas>
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
    </div>
  <!-- /.content-wrapper -->

  <!-- Main Footer -->
  <footer class="main-footer">
    <strong>&copy; Copyright <a href="#">Implementasi Metode Fuzzy C-Means untuk Klasifikasi Gizi Balita <?php echo date('Y') ?></a>.</strong>
  </footer>
</div>
<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url('assets/js/jquery-2.2.3.min.js')?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/js/app.min.js')?>"></script>
</body>
</html>
