  <p>
    ini bagian footer
  </p>
</body>
</html>
