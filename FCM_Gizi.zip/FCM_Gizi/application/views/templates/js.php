<script type="text/javascript">
$(document).ready(function() {
  $('.isi').load('home.html');
  $('.content-header h1').html('Halaman Admin');
  $('table').DataTable({
      "language":{
        "lengthMenu":"Tampilkan _MENU_ data per halaman.",
        "info":"Menampilkan _START_ - _END_ dari _TOTAL_ data.",
        "zeroRecords":"Tidak ditemukan data yang sesuai.",
        "infoEmpty":"Menampilkan 0 - 0 dari 0 data.",
        "search":"Cari",
        "infoFiltered":"(disaring dari _MAX_ entri keseluruhan)",
        "thousands":".",
        "emptyTable":"Tidak ada data yang ditampilkan",
        "paginate":{
          "first":"<<",
          "last":">>",
          "next":"> Selanjutnya",
          "previous":"Sebelumnya <"
        }
      }
    });
});
</script>
