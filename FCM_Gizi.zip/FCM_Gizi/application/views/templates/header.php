<!DOCTYPE htnl>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Selamat datang  di halaman <?php echo $judul;?> member sekolahkoding</h1>
