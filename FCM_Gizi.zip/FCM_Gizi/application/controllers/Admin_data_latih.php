<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_data_latih extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}

	//memanggil data latih
	public function data_latih()
  {
    $this->load->helper('url');
    $this->load->model('Data_latih');
		$data['data_latih'] = $this->Data_latih->get_data_latih();
    $this->load->view('admin/tampilan/input_data_latih',$data);
  }

//memanggil menyimpan input data latih
	public function input_data_latih()
	{
		// var_dump($data);
		// die();
		$this->load->helper('url');
		$this->load->model('Data_latih');
		$data['data_latih'] = $this->Data_latih->get_data_latih();
		$this->load->view('admin/tampilan/input_data_latih',$data);
	}


		// controller delete_data latih
		public function delete_data_latih()
		{
			$this->load->helper('url');
			$this->load->model('Data_latih');

			$id_data_latih = $this->input->post('id_data_latih');
			$data=$this->Data_latih->delete_data_latih($id_data_latih);

			if ($data) {
				redirect(base_url('Admin_data_latih/input_data_latih'));
			}

		}

		// controller edit_data latih di panggil ke ajax
		public function edit_data_latih(){
			$this->load->helper('url');
			$this->load->model('Data_latih');

	    $id_data_latih = $this->input->get('id_data_latih');
	    $data =$this->Data_latih->edit_data_latih($id_data_latih);
			// var_dump($data);
			// die();
			//(diganti) jadi ringkes kan :p :D mie ayam
			echo json_encode($data[0]);
	  }

	 //menyimpan edit Data_latih
		public function update_data_latih()
		{
			$id_data_latih = $this->input->post('id_data_latih');
			$nama= $this->input->post('nama');
			$jenis_kelamin = $this->input->post('jenis_kelamin');
			$umur= $this->input->post('umur');
			$tinggi_badan = $this->input->post('tinggi_badan');
			$berat_badan = $this->input->post('berat_badan');
			$status_gizi = $this->input->post('status_gizi');

			$this->load->helper('url');
			$this->load->model('Data_latih');
			$update = $this->Data_latih->update_data_latih($id_data_latih,$nama,$jenis_kelamin,$umur,$tinggi_badan,$berat_badan,$status_gizi);
			if ($update) {
				redirect(base_url('Admin_data_latih/input_data_latih'));
			}
		}


	public function simpan_data_latih()
	{
		// $id_data_latih = $this->input->post('id_data_latih');
		$nama = $this->input->post('nama');
		$jenis_kelamin= $this->input->post('jenis_kelamin');
		$umur = $this->input->post('umur');
		$tinggi_badan = $this->input->post('tinggi_badan');
		$berat_badan = $this->input->post('berat_badan');
		$status_gizi = $this->input->post('status_gizi');

		$this->load->helper('url');
		$this->load->model('Data_latih');


		$cek_data_latih = $this->Data_latih->cek_data_latih($nama);
		// var_dump($cek_data_latih);
		// die();


		if ($cek_data_latih>0) {
			$this->session->set_flashdata('gagal','data sudah ada');
			redirect(base_url('Admin_data_latih/input_data_latih'));
		}
		else {
			$simpan = $this->Data_latih->input_data_latih($nama,$jenis_kelamin,$umur,$tinggi_badan,$berat_badan,$status_gizi);
			$this->session->set_flashdata('sukses','data tersimpan');
			redirect(base_url('Admin_data_latih/input_data_latih'));
		}
	}

}
