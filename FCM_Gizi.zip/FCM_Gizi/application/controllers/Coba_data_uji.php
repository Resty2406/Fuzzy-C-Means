<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Coba_data_uji extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}

	public function simpan_data_uji()
	{
		$this->load->helper('url');
		$this->load->model('Data_uji');

		//$data_uji = $this->Data_uji->get_min_data_uji('umur');
		// echo $data_uji;
		// die();

		// $id_data_uji = $this->input->post('id_data_uji');
		$nama = $this->input->post('nama');
		$jenis_kelamin= $this->input->post('jenis_kelamin');
		$umur = $this->input->post('umur');
		$tinggi_badan = $this->input->post('tinggi_badan');
		$berat_badan = $this->input->post('berat_badan');
		$C_1= $this->input->post('C_1');
		$C_2 = $this->input->post('C_2');
		$C_3 = $this->input->post('C_3');
		$C_4 = $this->input->post('C_4');
		//$status_gizi = $this->input->post('status_gizi');
		$umur = array();
		$tinggi_badan = array();
		$berat_badan = array();

		// //wahdah C baru
		// $c1_wadah_baru = array();
		// $c2_wadah_baru = array();
		// $c3_wadah_baru = array();
		// $c4_wadah_baru = array();

		//digunakan untuk mengambil isi data uji (limit 20)
		$data=$this->db->order_by('id_data_uji','desc')->limit(20)->get('data_uji')->result();
		// var_dump($data);
		// die();

		$data_c1=array();
		$data_c2=array();
		$data_c3=array();
		$data_c4=array();
		// $data_c= $data[$i]->C_1;
		for ($i=0; $i < count($data) ; $i++) {
			array_push($data_c1, $data[$i]->C_1);
			array_push($data_c2, $data[$i]->C_2);
			array_push($data_c3, $data[$i]->C_3);
			array_push($data_c4, $data[$i]->C_4);
			// echo "\n";
			// var_dump($data_c1);
			// echo "\n";
			// echo $data_c1[$i];
		}

		// var_dump($data_c);
		// die();

		$P0 = 0;
		$P2 = 0;
		$loop = 1;
		while (($P0 >= 0.00001) || $loop <= 100 ) {

			echo $loop;
			echo "<br>";
			// die();

			if ($loop==1) {
				foreach ($data as $key => $value) {
				//print_r($value);die();
					array_push($umur,$value->umur);
					array_push($tinggi_badan,$value->tinggi_badan);
					array_push($berat_badan,$value->berat_badan);
				}
			}
			else {

			}
			//umur max min
			$umurmax= max($umur);
			$umurmin= min($umur);
			//tinggi max min
			$tinggimax= max($tinggi_badan);
			$tinggimin= min($tinggi_badan);
			//berat badan min max
			$beratmax= max($berat_badan);
			$beratmin= min($berat_badan);

			//tahap normalisasi
			//$normalisasi_umur=(($umur-$umurmin)/($umurmax-$umurmin))*1-0+0;
			$normalisasiumur = array();
			$normalisasitinggi = array();
			$normalisasiberat = array();
			//print_r($tinggimin);die();
			foreach ($data as $key => $value) {

				//normalisasi umur
				$tempumur=0;
				if (($umurmax-$umurmin) == 0) {
					$tempumur=0;
					array_push($normalisasiumur, $tempumur);
				}
				else {
					$tempumur=(($value->umur-$umurmin)/($umurmax-$umurmin))*1-0+0;
					array_push($normalisasiumur, round($tempumur,2));
				}
				//normalisasi tinggi
				$temptinggi=0;
				if (($tinggimax-$tinggimin) == 0) {
					$temptinggi=0;
					array_push($normalisasitinggi, $temptinggi);
				}
				else {
					$temptinggi=(($value->tinggi_badan-$tinggimin)/($tinggimax-$tinggimin))*1-0+0;
					array_push($normalisasitinggi, round($temptinggi,2));
				}
				//normalisasi berat
				$tempberat=0;
				if (($beratmax-$beratmin) == 0) {
					$tempberat=0;
					array_push($normalisasiberat, $tempberat);
				}
				else {
					$tempberat=(($value->berat_badan-$beratmin)/($beratmax-$beratmin))*1-0+0;
					//round(520.34345,2);
					array_push($normalisasiberat, round($tempberat,2));
				}
			}

			echo "Nilai Normalisasi";
			echo "<br>";
			print_r(($normalisasiumur));
			echo "<br>";
			print_r(($normalisasitinggi));
			echo "<br>";
			print_r(($normalisasiberat));
			echo "<br>";
			echo "<br>";

			//tahap ketentuan
			// $error=0.00001;
			// $maxiterasi=100;
			// $P0=0;
			// $w=2;

			//variabel FCM
			$keanggotaanc1 = array(); //derajat keanggotaan == nilai matriks random
			$keanggotaanc2 = array();
			$keanggotaanc3 = array();
			$keanggotaanc4 = array();

			$x1c1 = array(); // X1 adalah nilai normalisasi umur
			$x2c1 = array(); // X2 adalah nilai normalisasi tinggi badan
			$x3c1 = array(); // X3 adalah nilai normalisasi berat badan

			$miuc1 = array();
			$miux1c1 = array();
			$miux2c1 = array();
			$miux3c1 = array();

			$x1c2 = array();
			$x2c2 = array();
			$x3c2 = array();
			$miuc2 = array();

			$miux1c2 = array();
			$miux2c2 = array();
			$miux3c2 = array();

			$x1c3 = array();
			$x2c3 = array();
			$x3c3 = array();

			$miuc3 = array();
			$miux1c3 = array();
			$miux2c3 = array();
			$miux3c3 = array();

			$x1c4 = array();
			$x2c4 = array();
			$x3c4 = array();
			$miuc4 = array();

			$miux1c4 = array();
			$miux2c4 = array();
			$miux3c4 = array();

			$summiuc1 = 0; // variabel jumlah dari miu
			$summiuc2 = 0;
			$summiuc3 = 0;
			$summiuc4 = 0;

			$summiux1c1 = 0;
			$summiux2c1 = 0;
			$summiux3c1 = 0;

			$summiux1c2 = 0;
			$summiux2c2 = 0;
			$summiux3c2 = 0;

			$summiux1c3 = 0;
			$summiux2c3 = 0;
			$summiux3c3 = 0;

			$summiux1c4 = 0;
			$summiux2c4 = 0;
			$summiux3c4 = 0;

			$hasilbagimiux1c1 = 0; // variabel hasil perhitungan pusat cluster (V) C1
			$hasilbagimiux2c1 = 0;
			$hasilbagimiux3c1 = 0;

			$hasilbagimiux1c2 = 0; //variabel hasil perhitungan pusat cluster (V) C2
			$hasilbagimiux2c2 = 0;
			$hasilbagimiux3c2 = 0;

			$hasilbagimiux1c3 = 0; //variabel hasil perhitungan pusat cluster (V) C3
			$hasilbagimiux2c3 = 0;
			$hasilbagimiux3c3 = 0;

			$hasilbagimiux1c4 = 0; //variabel hasil perhitungan pusat cluster (V) C4
			$hasilbagimiux2c4 = 0;
			$hasilbagimiux3c4 = 0;

			//tahap 1 mencari pusat cluster
			//for untuk menghitung pusat cluster
			for ($i=0; $i < count($data) ; $i++) {

				array_push($keanggotaanc1,$data_c1[$i]); // derajat keanggotaan c1
				array_push($keanggotaanc2,$data_c2[$i]); // derajat keanggotaan c2
				array_push($keanggotaanc3,$data_c3[$i]); // derajat keanggotaan c3
				array_push($keanggotaanc4,$data_c4[$i]); // derajat keanggotaan c4

				// array_push($keanggotaanc1,object($data_c1)); // derajat keanggotaan c1
				// array_push($keanggotaanc2,object($data_c2)); // derajat keanggotaan c2
				// array_push($keanggotaanc3,object($data_c3)); // derajat keanggotaan c3
				// array_push($keanggotaanc4,object($data_c4)); // derajat keanggotaan c4
				// var_dump($keanggotaanc1);echo"<br><br>";
				// var_dump($keanggotaanc2);echo"<br><br>";
				// var_dump($keanggotaanc3);echo"<br><br>";
				// var_dump($keanggotaanc4);
// die();
				array_push($x1c1,$normalisasiumur[$i]);   //nilai normalisasi umur c1
				array_push($x2c1,$normalisasitinggi[$i]); //nilai normalisasi tinggi_badan
				array_push($x3c1,$normalisasiberat[$i]);  //nilai normalisasi berat_badan

				array_push($x1c2,$normalisasiumur[$i]);   //nilai normalisasi umur c2
				array_push($x2c2,$normalisasitinggi[$i]);
				array_push($x3c2,$normalisasiberat[$i]);

				array_push($x1c3,$normalisasiumur[$i]);  //nilai normalisasi umur c3
				array_push($x2c3,$normalisasitinggi[$i]);
				array_push($x3c3,$normalisasiberat[$i]);

				array_push($x1c4,$normalisasiumur[$i]);  //nilai normalisasi umur c4
				array_push($x2c4,$normalisasitinggi[$i]);
				array_push($x3c4,$normalisasiberat[$i]);

				//nilai miu (nilai random di kuadrat kan)
				array_push($miuc1, number_format((pow($keanggotaanc1[$i],2)), 3,'.',','));
				array_push($miuc2, number_format((pow($keanggotaanc2[$i],2)), 3,'.',','));
				array_push($miuc3, number_format((pow($keanggotaanc3[$i],2)), 3,'.',','));
				array_push($miuc4, number_format((pow($keanggotaanc4[$i],2)), 3,'.',','));

				//nilai dari miu kuadrat dikali dengan X
				// X1 = umur, X2 = tinggi, X3 = berat
				array_push($miux1c1, number_format((pow($keanggotaanc1[$i],2)*$x1c1[$i]), 3,'.',','));
				array_push($miux2c1, number_format((pow($keanggotaanc1[$i],2)*$x2c1[$i]), 3,'.',','));
				array_push($miux3c1, number_format((pow($keanggotaanc1[$i],2)*$x3c1[$i]), 3,'.',','));

				array_push($miux1c2, number_format((pow($keanggotaanc2[$i],2)*$x1c2[$i]), 3,'.',','));
				array_push($miux2c2, number_format((pow($keanggotaanc2[$i],2)*$x2c2[$i]), 3,'.',','));
				array_push($miux3c2, number_format((pow($keanggotaanc2[$i],2)*$x3c2[$i]), 3,'.',','));

				array_push($miux1c3, number_format((pow($keanggotaanc3[$i],2)*$x1c3[$i]), 3,'.',','));
				array_push($miux2c3, number_format((pow($keanggotaanc3[$i],2)*$x2c3[$i]), 3,'.',','));
				array_push($miux3c3, number_format((pow($keanggotaanc3[$i],2)*$x3c3[$i]), 3,'.',','));

				array_push($miux1c4, number_format((pow($keanggotaanc4[$i],2)*$x1c4[$i]), 3,'.',','));
				array_push($miux2c4, number_format((pow($keanggotaanc4[$i],2)*$x2c4[$i]), 3,'.',','));
				array_push($miux3c4, number_format((pow($keanggotaanc4[$i],2)*$x3c4[$i]), 3,'.',','));
			}

			//jumlah total miu
			$summiuc1 = array_sum($miuc1);
			$summiuc2 = array_sum($miuc2);
			$summiuc3 = array_sum($miuc3);
			$summiuc4 = array_sum($miuc4);

			//jumlah dari miu kuadrat dikali dengan X
			//jumlah dari miu kuadrat dikali dengan X pada cluster 1
			$summiux1c1 = array_sum($miux1c1);
			$summiux2c1 = array_sum($miux2c1);
			$summiux3c1 = array_sum($miux3c1);

			//jumlah dari miu kuadrat dikali dengan X pada cluster 2
			$summiux1c2 = array_sum($miux1c2);
			$summiux2c2 = array_sum($miux2c2);
			$summiux3c2 = array_sum($miux3c2);

			//jumlah dari miu kuadrat dikali dengan X pada cluster 3
			$summiux1c3 = array_sum($miux1c3);
			$summiux2c3 = array_sum($miux2c3);
			$summiux3c3 = array_sum($miux3c3);

			//jumlah dari miu kuadrat dikali dengan X pada cluster 4
			$summiux1c4 = array_sum($miux1c4);
			$summiux2c4 = array_sum($miux2c4);
			$summiux3c4 = array_sum($miux3c4);

			//hasil perhitungan pusat cluster
			//hasil perhitungan (total miu kuadrat dikali X)/(total miu kuadrat) di C1
			$hasilbagimiux1c1 = number_format($summiux1c1/$summiuc1,3,'.',',');
			$hasilbagimiux2c1 = number_format($summiux2c1/$summiuc1,3,'.',',');
			$hasilbagimiux3c1 = number_format($summiux3c1/$summiuc1,3,'.',',');

			//hasil perhitungan (total miu kuadrat dikali X)/(total miu kuadrat) di C2
			$hasilbagimiux1c2 = number_format($summiux1c2/$summiuc2,3,'.',',');
			$hasilbagimiux2c2 = number_format($summiux2c2/$summiuc2,3,'.',',');
			$hasilbagimiux3c2 = number_format($summiux3c2/$summiuc2,3,'.',',');

			//hasil perhitungan (total miu kuadrat dikali X)/(total miu kuadrat) di C3
			$hasilbagimiux1c3 = number_format($summiux1c3/$summiuc3,3,'.',',');
			$hasilbagimiux2c3 = number_format($summiux2c3/$summiuc3,3,'.',',');
			$hasilbagimiux3c3 = number_format($summiux3c3/$summiuc3,3,'.',',');

			//hasil perhitungan (total miu kuadrat dikali X)/(total miu kuadrat) di C4
			$hasilbagimiux1c4 = number_format($summiux1c4/$summiuc4,3,'.',',');
			$hasilbagimiux2c4 = number_format($summiux2c4/$summiuc4,3,'.',',');
			$hasilbagimiux3c4 = number_format($summiux3c4/$summiuc4,3,'.',',');

			echo "Nilai Miu kuadrat";
			echo "<br>";
			print_r(($miuc1));
			echo "<br>";
			print_r(($miuc2));
			echo "<br>";
			print_r(($miuc3));
			echo "<br>";
			print_r(($miuc4));
			echo "<br>";
			echo "<br>";
			echo "Hasil Pusat Cluster (V)";
			echo "<br>";
			echo "C1 ";
			print_r(($hasilbagimiux1c1));
			echo "    ";
			print_r(($hasilbagimiux2c1));
			echo "    ";
			print_r(($hasilbagimiux3c1));
			echo "<br>";
			echo "C2 ";
			print_r(($hasilbagimiux1c2));
			echo "    ";
			print_r(($hasilbagimiux2c2));
			echo "    ";
			print_r(($hasilbagimiux3c2));
			echo "<br>";
			echo "C3 ";
			print_r(($hasilbagimiux1c3));
			echo "    ";
			print_r(($hasilbagimiux2c3));
			echo "    ";
			print_r(($hasilbagimiux3c3));
			echo "<br>";
			echo "C4 ";
			print_r(($hasilbagimiux1c4));
			echo "    ";
			print_r(($hasilbagimiux2c4));
			echo "    ";
			print_r(($hasilbagimiux3c4));
			echo "<br>";
			echo "<br>";

			//tahap 2 perhitungan fungsi objektif (P1)
			$l1 = array();
			$l2 = array();
			$l3 = array();
			$l4 = array();
			$ltotal = array();
			$FOtotal = array();

			//menghitung nilai P1
			for ($i=0; $i < count($data) ; $i++) {
				$l1[$i]=(pow(($x1c1[$i]-$hasilbagimiux1c1),2)+ pow(($x2c1[$i]-$hasilbagimiux2c1),2)+ pow(($x3c1[$i]-$hasilbagimiux3c1),2)) * $miuc1[$i];

				$l2[$i]=(pow(($x1c1[$i]-$hasilbagimiux1c2),2)+ pow(($x2c1[$i]-$hasilbagimiux2c2),2)+ pow(($x3c1[$i]-$hasilbagimiux3c2),2)) * $miuc2[$i];

				$l3[$i]=(pow(($x1c1[$i]-$hasilbagimiux1c3),2)+ pow(($x2c1[$i]-$hasilbagimiux2c3),2)+ pow(($x3c1[$i]-$hasilbagimiux3c3),2)) * $miuc3[$i];

				$l4[$i]=(pow(($x1c1[$i]-$hasilbagimiux1c4),2)+ pow(($x2c1[$i]-$hasilbagimiux2c4),2)+ pow(($x3c1[$i]-$hasilbagimiux3c4),2)) * $miuc4[$i];

				$ltotal[$i]=$l1[$i]+$l2[$i]+$l3[$i]+$l4[$i];
			}
			//nilai P1 yang digunakan untuk mengurangi P0
			$FOtotal=array_sum($ltotal);

			echo "Nilai Fungsi Objektif ";
			print_r($FOtotal);
			echo "<br>";
			echo "<br>";

			//tahap 3 perhitungan matriks partisi baru dan atau untuk menentukan nilai random baru dan atau untuk menentukan klasifikasi cluster jika kondisi error terpenuhi (diambil nilai max nya untuk menentukan masuk ke cluster mana)
			$L_1 = array();
			$L_2 = array();
			$L_3 = array();
			$L_4 = array();
			$L_total = array();

			for ($i=0; $i < count($data) ; $i++) {
				$L_1[$i]=pow((pow(($x1c1[$i]-$hasilbagimiux1c1),2)+ pow(($x2c1[$i]-$hasilbagimiux2c1),2)+ pow(($x3c1[$i]-$hasilbagimiux3c1),2)),-1);

				$L_2[$i]=pow((pow(($x1c1[$i]-$hasilbagimiux1c2),2)+ pow(($x2c1[$i]-$hasilbagimiux2c2),2)+ pow(($x3c1[$i]-$hasilbagimiux3c2),2)),-1);

				$L_3[$i]=pow((pow(($x1c1[$i]-$hasilbagimiux1c3),2)+ pow(($x2c1[$i]-$hasilbagimiux2c3),2)+ pow(($x3c1[$i]-$hasilbagimiux3c3),2)),-1);

				$L_4[$i]=pow((pow(($x1c1[$i]-$hasilbagimiux1c4),2)+ pow(($x2c1[$i]-$hasilbagimiux2c4),2)+ pow(($x3c1[$i]-$hasilbagimiux3c4),2)),-1);

				$L_total[$i]=$L_1[$i]+$L_2[$i]+$L_3[$i]+$L_4[$i];
			}

			//menghitung nilai matriks random baru (untuk menentukan nilai keanggotaan baru pada iterasi selanjutnya jika kondisi error belum terpenuhi)
			$C1_baru = array();
			$C2_baru = array();
			$C3_baru = array();
			$C4_baru = array();

			for ($i=0; $i < count($data) ; $i++) {
					$C1_baru[$i]=number_format($L_1[$i]/$L_total[$i],3);
					$C2_baru[$i]=number_format($L_2[$i]/$L_total[$i],3);
					$C3_baru[$i]=number_format($L_3[$i]/$L_total[$i],3);
					$C4_baru[$i]=number_format($L_4[$i]/$L_total[$i],3);
					//$L_total[$i],3);
			}
			echo "Nilai Cluster BARU";
			echo "<br>";
			print_r(($C1_baru));
			echo "<br>";
			print_r(($C2_baru));
			echo "<br>";
			print_r(($C3_baru));
			echo "<br>";
			print_r(($C4_baru));
			echo "<br>";
			// die();

			//tahap 4 menghitung P1-P0
			// jika hasil P1-P0 belum 0.00001 maka proses hitung dilanjutkan ke iterasi selanjutnya (ulang perhitungan dari tahap 1)
			//nilai random pada iterasi selanjutnya di ambil dari nilai C baru di tahap 3
			// jika hasil P1-P0 sudah mencapai 0.00001 maka proses hitung selesai
			// dan proses selanjutnya adalah menentukan klasifikasi status gizi berdasarkan nilai maksimum pada C_baru di iterasi paling akhir
			// keterangan $C1_baru adalah C1 == Sangat Kurus
			// keterangan $C2_baru adalah C2 == Kurus
			// keterangan $C3_baru adalah C3 == Normal
			// keterangan $C4_baru adalah C4 == Gemuk
			//rumus


			$P1=$FOtotal;
      // $P0=$P1;  p0

			//jika kondisi error belum terpenuhi, maka nilai P1 digunakan sebagai nilai P0 yang baru
			$P2 = (abs($P1-$P0));
			//perhitungan penentuan p selesai

			$data_c1=$C1_baru;
			$data_c2=$C2_baru;
			$data_c3=$C3_baru;
			$data_c4=$C4_baru;
			// $P_0=$P0;
			// $P0=$P1;


			if ((abs($P1-$P0)) <= 0.00001 || $loop <= 100 ) {
			$data_c1=$C1_baru;
			$data_c2=$C2_baru;
			$data_c3=$C3_baru;
			$data_c4=$C4_baru;
			// var_dump($data_c1);
			// var_dump($data_c2);
			// var_dump($data_c3);
			// var_dump($data_c4);

			// die();
			}
			else {
				$P0 = $P1;
				echo $P0;
				//print_r($C1_baru);die();
			}
			echo "<br>";
			echo "nilai P1 = ";
			print_r(($P1));
			echo "<br>";
			echo "nilai P0 = ";
			print_r(($P0));
			echo "<br>";
			echo "nilai P2 = ";
			print_r(($P2));
			echo "<br>";
      echo "keanggotaan yang baru <br>";
			print_r(($data_c1));
			echo "<br>";
			echo "<br>";
			$loop++;

      // echo "keanggotaan yang baru <br>";
      // print_r($keanggotaanc1);
      // echo "<br>";
      // print_r($keanggotaanc2);
      // echo "<br>";
      // print_r($keanggotaanc3);
      // echo "<br>";
      // print_r($keanggotaanc4);
      // echo "<br>";
      // echo "selesai sampai disini <br>";
		}
		die();

  }

function random_nilai()
{
	$angka = '12324567890';
	$pos_angka_random = '';
	for ($i=1; $i <= 3 ; $i++) {
		$ambil_angka = rand(0, strlen($angka) -1);
		$pos_angka_random .= $angka{$ambil_angka};
	}
	// echo "0.$pos_angka_random";
	// die();
	return '0.'.$pos_angka_random;
}

function random_nilai2()
{
	$angka = '12324567890';
	$pos_angka_random = '';
	for ($i=1; $i <= 3 ; $i++) {
		$ambil_angka = rand(0, strlen($angka) -2);
		$pos_angka_random .= $angka{$ambil_angka};
	}
	// echo "0.$pos_angka_random";
	// die();
	return '0.'.$pos_angka_random;
}

function random_nilai3()
{
	$angka = '12324567890';
	$pos_angka_random = '';
	for ($i=1; $i <= 3 ; $i++) {
		$ambil_angka = rand(0, strlen($angka) -3);
		$pos_angka_random .= $angka{$ambil_angka};
	}
	// echo "0.$pos_angka_random";
	// die();
	return '0.'.$pos_angka_random;
}

function random_nilai4()
{
	$angka = '12324567890';
	$pos_angka_random = '';
	for ($i=1; $i <= 3 ; $i++) {
		$ambil_angka = rand(0, strlen($angka) -4);
		$pos_angka_random .= $angka{$ambil_angka};
	}
	// echo "0.$pos_angka_random";
	// die();
	return '0.'.$pos_angka_random;
}

}
?>
