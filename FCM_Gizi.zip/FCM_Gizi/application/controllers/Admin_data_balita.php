<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_data_balita extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}

	//memanggil data balita
	public function data_balita()
  {
    $this->load->helper('url');
    $this->load->model('Data_balita');
		$data['data_balita'] = $this->data_balita->get_data_balita();
    $this->load->view('admin/tampilan/input_data_balita',$data);
  }

//memanggil menyimpan input data uji
	public function input_data_balita()
	{
		// var_dump($data);
		// die();
		$this->load->helper('url');
		$this->load->model('Data_balita');
		$data['data_balita'] = $this->Data_balita->get_data_balita();
		$data['c1']=$this->random_nilai();
		$data['c2']=$this->random_nilai2();
		$data['c3']=$this->random_nilai3();
		$data['c4']=$this->random_nilai4();

		$this->load->view('admin/tampilan/input_data_balita',$data);
	}


		// controller delete_data uji
		public function delete_data_balita()
		{
			$this->load->helper('url');
			$this->load->model('Data_balita');

			$id_data_balita = $this->input->post('id_data_balita');
			$data=$this->data_balita->delete_data_balita($id_data_balita);
			if ($data) {
				redirect(base_url('Admin_data_balita/input_data_balita'));
			}

		}

		// controller edit_data uji di panggil ke ajax
		public function edit_data_balita(){
			$this->load->helper('url');
			$this->load->model('Data_balita');

	    $id_data_balita = $this->input->get('id_data_balita');
	    $data =$this->data_balita->edit_data_balita($id_data_balita);
			// var_dump($data);
			// die();
	    foreach ($data as $data) {
	      echo '<div id="id_data_balita">'.$data->id_data_balita.'</div>';
				echo '<div id="nama">'.$data->nama.'</div>';
	      echo '<div id="jenis_kelamin">'.$data->jenis_kelamin.'</div>';
	      echo '<div id="umur">'.$data->umur.'</div>';
				echo '<div id="tinggi_badan">'.$data->tinggi_badan.'</div>';
				echo '<div id="berat_badan">'.$data->berat_badan.'</div>';
				echo '<div id="status_gizi">'.$data->status_gizi.'</div>';
	    }
	  }

	 //menyimpan edit data uji
		public function update_data_balita()
		{
			$id_data_balita = $this->input->post('id_data_balita');
			$nama= $this->input->post('nama');
			$jenis_kelamin = $this->input->post('jenis_kelamin');
			$umur= $this->input->post('umur');
			$tinggi_badan = $this->input->post('tinggi_badan');
			$berat_badan = $this->input->post('berat_badan');
			$status_gizi = $this->input->post('status_gizi');

			$this->load->helper('url');
			$this->load->model('Data_balita');
			$update = $this->data_balita->update_data_balita($id_data_balita,$nama,$jenis_kelamin,$umur,$tinggi_badan,$berat_badan,$status_gizi);
			if ($update) {
				redirect(base_url('Admin_data_balita/input_data_balita'));
			}
		}


	public function simpan_data_balita()
	{
		$this->load->helper('url');
		$this->load->model('Data_balita');

		$nama = $this->input->post('nama');
		$jenis_kelamin= $this->input->post('jenis_kelamin');
		$umur = $this->input->post('umur');
		$tinggi_badan = $this->input->post('tinggi_badan');
		$berat_badan = $this->input->post('berat_badan');
		$C_1= $this->input->post('C_1');
		$C_2 = $this->input->post('C_2');
		$C_3 = $this->input->post('C_3');
		$C_4 = $this->input->post('C_4');
		$status_gizi = $this->input->post('status_gizi');

		$cek_data_balita = $this->Data_balita->cek_data_balita($nama);
		// var_dump($cek_data_balita);
		// die();

		if ($cek_data_balita>0) {
			$this->session->set_flashdata('gagal','data sudah ada');
			redirect(base_url('Admin_data_balita/input_data_balita'));
		}
		else {
			$simpan = $this->Data_balita->input_data_balita($nama,$jenis_kelamin,$umur,$tinggi_badan,$berat_badan,$C_1,$C_2,$C_3,$C_4,$status_gizi);

			$this->session->set_flashdata('sukses','data tersimpan');
			redirect(base_url('Admin_data_balita/input_data_balita'));
		}
	}

function random_nilai()
{
	$angka = '12324567890';
	$pos_angka_random = '';
	for ($i=1; $i <= 3 ; $i++) {
		$ambil_angka = rand(0, strlen($angka) -1);
		$pos_angka_random .= $angka{$ambil_angka};
	}
	// echo "0.$pos_angka_random";
	// die();
	return '0.'.$pos_angka_random;
}

function random_nilai2()
{
	$angka = '12324567890';
	$pos_angka_random = '';
	for ($i=1; $i <= 3 ; $i++) {
		$ambil_angka = rand(0, strlen($angka) -2);
		$pos_angka_random .= $angka{$ambil_angka};
	}
	// echo "0.$pos_angka_random";
	// die();
	return '0.'.$pos_angka_random;
}

function random_nilai3()
{
	$angka = '12324567890';
	$pos_angka_random = '';
	for ($i=1; $i <= 3 ; $i++) {
		$ambil_angka = rand(0, strlen($angka) -3);
		$pos_angka_random .= $angka{$ambil_angka};
	}
	// echo "0.$pos_angka_random";
	// die();
	return '0.'.$pos_angka_random;
}
 
function random_nilai4()
{
	$angka = '12324567890';
	$pos_angka_random = '';
	for ($i=1; $i <= 3 ; $i++) {
		$ambil_angka = rand(0, strlen($angka) -4);
		$pos_angka_random .= $angka{$ambil_angka};
	}
	// echo "0.$pos_angka_random";
	// die();
	return '0.'.$pos_angka_random;
}

}
