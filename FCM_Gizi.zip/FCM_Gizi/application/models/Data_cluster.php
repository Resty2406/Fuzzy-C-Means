<?php
/**
 *
 */
class Data_cluster extends CI_Model
{

  function __construct()
  {
    $this->load->database();
  }


  public function get_data_cluster()
  {
    $this->db->from('data_cluster');
    $query = $this->db->order_by('id_data_cluster','desc')->get();
    $data = $query->result();
    return $data;
  }

  public function input_data_cluster($C1,$C2,$C3,$C4)
  {
    $data = array(
      'C1'=>$C1,
      'C2'=>$C2,
      'C3'=>$C3,
      'C4'=>$C4
    );
    // die(var_dump($data));
    return $this->db->insert('data_cluster',$data);
  }
}
