<?php
/**
 *
 */
class Data_Latih extends CI_Model
{

  function __construct()
  {
    $this->load->database();
  }

  //ambil data latih
  public function get_data_latih()
  {
    //$this->db->from('data_latih');
    $query = $this->db->get('data_latih');
    $data = $query->result();
    return $data;
  }

  //model untuk edit berdasar id
    public function edit_data_latih($id_data_latih)
    {
      $this->db->from('data_latih');
      $this->db->where('id_data_latih',$id_data_latih);
      $query = $this->db->get();
      return $query->result();
    }

    // model delete data latih
    function delete_data_latih($id_data_latih)
    {

      $this->db->where('id_data_latih',$id_data_latih);
      $query = $this->db->delete('data_latih');
      return $query;
    }

  public function get_data_latih_id()
  {
    $sesi=$_SESSION['username'];
    $this->db->from('data_latih');
    $this->db->where('username',$sesi);
    $query = $this->db->get();
    $data = $query->row();
    return $data;
  }

  //untuk memasukan data latih
  public function input_data_latih($nama,$jenis_kelamin,$umur,$tinggi_badan,$berat_badan,$status_gizi)
  {
    $data = array(
      'nama'=>$nama,
      'jenis_kelamin'=>$jenis_kelamin,
      'umur'=>$umur,
      'tinggi_badan'=>$tinggi_badan,
      'berat_badan'=>$berat_badan,
      'status_gizi'=>$status_gizi
    );
    // die(var_dump($data));
    return $this->db->insert('data_latih',$data);
  }

  //menyimpan edit data latih
  public function update_data_latih($id_data_latih,$nama,$jenis_kelamin,$umur,$tinggi_badan,$berat_badan,$status_gizi)
  {
    $this->db->where('id_data_latih',$id_data_latih);
    $data = array(
      'nama'=> $nama,
      'jenis_kelamin' => $jenis_kelamin,
      'umur' => $umur,
      'tinggi_badan'=>$tinggi_badan,
      'berat_badan'=>$berat_badan,
      'status_gizi'=>$status_gizi
    );
    //print_r($data);die();
    $query=$this->db->update('data_latih',$data);
    return $query;
  }

  //ini buat edit nih CI_Controller
  //nanti ini dipanggil di controller
  public function get_data_latih_satuan($id)
  {
    $this->db->from('data_latih');
    $this->db->where('id_data_latih',$id_data_latih);
    $query = $this->db->get();
    $data = $query->row();
    return $data;
  }

  public function cek_data_latih($id_data_latih,$nama)
  {
    $this->db->from('data_latih');
    $this->db->where('id_data_latih',$id_data_latih);
    $this->db->where('nama',$nama);
    $data = $this->db->get();
    return $data->num_rows();
  }

  // public function cek_data_latih($nama)
  // {
  //   $this->db->from('data_latih');
  //   // $this->db->where('kode_petak',$kode_petak);
  //   $this->db->where('nama',$nama);
  //   $data = $this->db->get();
  //   return $data->num_rows();
  // }

}

?>
