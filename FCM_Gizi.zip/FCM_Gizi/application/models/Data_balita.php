<?php
/**
*
*/
class Data_balita extends CI_Model
{

  function __construct()
  {
    $this->load->database();
  }

  //ambil data uji
  public function get_data_balita()
  {
    $this->db->from('data_balita');
    $query = $this->db->get();
    $data = $query->result();
    return $data;
  }

  // public function get_min_data_balita($where)
  // {
  //   $sql = "SELECT MIN($where) FROM data_balita";
  //   $query = $this->db->query($sql)->row();
  //   return $query;
  // }
  //
  // public function get_max_data_balita($where)
  // {
  //   $sql = "SELECT MAX($where) FROM data_balita";
  //   $query = $this->db->query($sql)->row();
  //   return $query;
  // }


  //model untuk edit berdasar id
  public function edit_data_balita($id_data_balita)
  {
    $this->db->from('data_balita');
    $this->db->where('id_data_balita',$id_data_balita);
    $query = $this->db->get();
    return $query->result();
  }

  // model delete data balita
  function delete_data_balita($id_data_balita)
  {

    $this->db->where('id_data_balita',$id_data_balita);
    $query = $this->db->delete('data_balita');
    return $query;
  }

  //memanggil data balita berdasarkan id
  // public function get_data_balita_id()
  // {
  //   $sesi=$_SESSION['username'];
  //   $this->db->from('data_balita');
  //   $this->db->where('username',$sesi);
  //   $query = $this->db->get();
  //   $data = $query->row();
  //   return $data;
  // }

  //input data balita
  public function input_data_balita($nama,$jenis_kelamin,$umur,$tinggi_badan,$berat_badan,$C_1,$C_2,$C_3,$C_4,$status_gizi)
  {
    $data = array(
      'nama'=>$nama,
      'jenis_kelamin'=>$jenis_kelamin,
      'umur'=>$umur,
      'tinggi_badan'=>$tinggi_badan,
      'berat_badan'=>$berat_badan,
      'C_1'=>$C_1,
      'C_2'=>$C_2,
      'C_3'=>$C_3,
      'C_4'=>$C_4,
      'status_gizi'=>$status_gizi
    );
    // die(var_dump($data));
    return $this->db->insert('data_balita',$data);
  }

  //menyimpan edit data balita
  public function update_data_balita($id_data_balita,$nama,$jenis_kelamin,$umur,$tinggi_badan,$berat_badan,$status_gizi)
  {
    $this->db->where('id_data_balita',$id_data_balita);
    $data = array(
      'nama'=> $nama,
      'jenis_kelamin' => $kode_petak,
      'umur' => $umur,
      'tinggi_badan'=>$tinggi_badan,
      'berat_badan'=>$berat_badan,
      'status_gizi'=>$status_gizi
    );
    $query=$this->db->update('data_balita',$data);
    return $query;
  }

  //ini buat edit nih CI_Controller
  //nanti ini dipanggil di controller
  public function get_data_balita_satuan($id)
  {
    $this->db->from('data_balita');
    $this->db->where('id_data_balita',$id_data_balita);
    $query = $this->db->get();
    $data = $query->row();
    return $data;
  }

  public function cek_data_balita($nama)
  {
    $this->db->from('data_balita');
    $this->db->where('nama',$nama);
    $data = $this->db->get();
    return $data->num_rows();
  }

}

?>
