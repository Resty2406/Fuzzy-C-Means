<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$route['default_controller'] = 'admin/index';
$route['halaman/(:any)'] = 'halaman/view/$1';


$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['admin']='admin';
// $route['kepala']='kepala/kepala';
// $route['tu']='tu';
// $route['editor']='editor';
// $route['auth'] = 'auth';
